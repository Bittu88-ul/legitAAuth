import os
import json
import asyncio
from typing import Optional
import discord
from discord import app_commands
import requests
from dotenv import load_dotenv

load_dotenv()

API_BASE = os.getenv("LEGITAUTH_API_URL", "https://legitauth1-3.onrender.com")
API_TOKEN = os.getenv("LEGITAUTH_API_TOKEN")
intents = discord.Intents.default()
client = discord.Client(intents=intents)

tree = app_commands.CommandTree(client)

# In‑memory mapping: Discord user ID -> selected app ID
user_selected_app: dict[int, int] = {}
guild_channel: dict[int, int] = {}

def api_headers():
    return {"Authorization": f"Bearer {API_TOKEN}"}

def get_linked_app(channel_id: int):
    url = f"{API_BASE}/api/creator/discord/app-by-channel/{channel_id}"
    try:
        resp = requests.get(url, headers=api_headers())
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return None

@tree.command(name="list_apps", description="List your LegitAuth applications")
async def list_apps(interaction: discord.Interaction):
    url = f"{API_BASE}/api/creator/apps"
    resp = requests.get(url, headers=api_headers())
    if resp.status_code != 200:
        await interaction.response.send_message("Failed to fetch apps.", ephemeral=True)
        return
    apps = resp.json()
    if not apps:
        await interaction.response.send_message("No applications found.", ephemeral=True)
        return
    embed = discord.Embed(title="Your Applications", color=0x00FFAA)
    for app in apps:
        guild_name = app.get("discord_guild_name") or "None"
        channel_name = app.get("discord_channel_name") or "None"
        embed.add_field(
            name=app["app_name"],
            value=f"ID: {app['id']}\nLinked Discord: {guild_name} (#{channel_name})",
            inline=False
        )
    await interaction.response.send_message(embed=embed, ephemeral=True)

@tree.command(name="select_app", description="Select an application to work with")
@app_commands.describe(app_id="Application ID from /list_apps")
async def select_app(interaction: discord.Interaction, app_id: int):
    url = f"{API_BASE}/api/creator/apps"
    resp = requests.get(url, headers=api_headers())
    if resp.status_code != 200:
        await interaction.response.send_message("Unable to verify app.", ephemeral=True)
        return
    apps = resp.json()
    selected = next((a for a in apps if a["id"] == app_id), None)
    if not selected:
        await interaction.response.send_message("App ID not found under your account.", ephemeral=True)
        return
    user_selected_app[interaction.user.id] = selected
    await interaction.response.send_message(f"Selected app **{selected['app_name']}** (ID: {app_id}).", ephemeral=True)

@tree.command(name="create_user", description="Create a new user/password for the selected app")
@app_commands.describe(username="New username", password="Password", expires_at="ISO datetime or leave blank", hwid_lock="Lock to HWID (true/false)")
async def create_user(interaction: discord.Interaction, username: str, password: str, expires_at: Optional[str] = None, hwid_lock: bool = True):
    app = user_selected_app.get(interaction.user.id)
    if not app:
        app = get_linked_app(interaction.channel_id)
        
    if not app:
        await interaction.response.send_message("No app selected or linked to this channel. Use `/select_app <app_id>` first or link this channel in the dashboard.", ephemeral=True)
        return
    
    app_id = app["id"]
    payload = {
        "username": username,
        "password": password,
        "expires_at": expires_at,
        "hwid_lock_enabled": hwid_lock,
    }
    url = f"{API_BASE}/api/creator/apps/{app_id}/users"
    resp = requests.post(url, json=payload, headers=api_headers())
    if resp.status_code == 200:
        await interaction.response.send_message(f"User **{username}** created successfully for application **{app['app_name']}**.", ephemeral=True)
    else:
        await interaction.response.send_message(f"Failed: {resp.json().get('detail', 'unknown error')}", ephemeral=True)

@tree.command(name="create_license", description="Generate licenses for the selected app")
@app_commands.describe(amount="Number of licenses", duration_days="Duration in days (0 = lifetime)", expires_at="ISO datetime or leave blank", hwid_lock="Lock to HWID (true/false)")
async def create_license(interaction: discord.Interaction, amount: int, duration_days: int = 0, expires_at: Optional[str] = None, hwid_lock: bool = True):
    app = user_selected_app.get(interaction.user.id)
    if not app:
        app = get_linked_app(interaction.channel_id)
        
    if not app:
        await interaction.response.send_message("No app selected or linked to this channel. Use `/select_app <app_id>` first or link this channel in the dashboard.", ephemeral=True)
        return
    
    app_id = app["id"]
    payload = {
        "amount": amount,
        "duration_days": duration_days,
        "expires_at": expires_at,
        "hwid_lock_enabled": hwid_lock,
    }
    url = f"{API_BASE}/api/creator/apps/{app_id}/licenses"
    resp = requests.post(url, json=payload, headers=api_headers())
    if resp.status_code == 200:
        data = resp.json()
        keys = "\n".join(data.get("keys", []))
        await interaction.response.send_message(f"Generated {amount} license(s) for **{app['app_name']}**:\n\n{keys}\n", ephemeral=True)
    else:
        await interaction.response.send_message(f"Failed: {resp.json().get('detail', 'unknown error')}", ephemeral=True)

@client.event
async def on_ready():
    await tree.sync()
    print(f"Logged in as {client.user}")

# Bot token should be stored in .env as DISCORD_BOT_TOKEN
client.run(os.getenv("DISCORD_BOT_TOKEN"))
